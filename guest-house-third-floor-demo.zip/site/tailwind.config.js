export default { content: ['./index.html','./src/**/*.{ts,tsx}'],
  theme: { extend: { colors: { ivory:'#F7F3EB', forest:'#243C33', gold:'#B79B63', walnut:'#574536', charcoal:'#252525' },
    fontFamily: { serif:['"Cormorant Garamond"','"Noto Serif Georgian"','Georgia','serif'], sans:['"Noto Sans"','"Noto Sans Georgian"','system-ui','sans-serif'] } } }, plugins: [] }
