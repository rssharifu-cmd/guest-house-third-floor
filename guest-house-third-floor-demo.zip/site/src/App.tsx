import { useEffect, useState } from 'react'
import { Lang, t, property as P, ratings, rooms, roomImg, pics, gallery, bathrooms, propertyWide, roomWide, themes, places, dirLink } from './content'

const useRoute = () => {
  const [h, setH] = useState(location.hash.replace(/^#\/?/, ''))
  useEffect(() => { const f = () => { setH(location.hash.replace(/^#\/?/, '')); window.scrollTo(0, 0) }; addEventListener('hashchange', f); return () => removeEventListener('hashchange', f) }, [])
  return h
}
const Img = ({ src, alt, cls = '' }: { src: string; alt: string; cls?: string }) => <img src={src} alt={alt} loading="lazy" decoding="async" className={`object-cover w-full h-full ${cls}`} />
const Rating = () => <p className="text-sm">{ratings.source}: <strong>{ratings.score}/10</strong> · {ratings.label} · {ratings.reviews} reviews <span className="opacity-70">(snapshot; to be reverified)</span></p>

function Inquiry({ tr, pre = '' }: { tr: Record<string, string>; pre?: string }) {
  const [f, setF] = useState({ cin: '', cout: '', ad: '2', ch: '0', room: pre })
  const [err, setErr] = useState<Record<string, string>>({}); const [txt, setTxt] = useState(''); const [ok, setOk] = useState(false)
  const set = (k: string, v: string) => setF({ ...f, [k]: v })
  const submit = (e: React.FormEvent) => {
    e.preventDefault(); const x: Record<string, string> = {}; const today = new Date().toISOString().slice(0, 10)
    if (!f.cin) x.cin = 'Choose a check-in date'; else if (f.cin < today) x.cin = 'Check-in cannot be in the past'
    if (!f.cout) x.cout = 'Choose a check-out date'; else if (f.cin && f.cout <= f.cin) x.cout = 'Check-out must be after check-in'
    if (!(+f.ad >= 1 && +f.ad <= 12)) x.ad = 'At least 1 adult'; if (!(+f.ch >= 0 && +f.ch <= 10)) x.ch = 'Enter 0–10'
    setErr(x); setOk(false)
    if (!Object.keys(x).length) setTxt(`Reservation inquiry — Guest House Third Floor\nCheck-in: ${f.cin}\nCheck-out: ${f.cout}\nAdults: ${f.ad}, Children: ${f.ch}\nRoom: ${f.room || tr.any}\n(Not a confirmed booking. Call ${P.phone}.)`)
  }
  const I = 'w-full border border-walnut/30 bg-white px-3 py-2 text-charcoal'
  return (
    <form onSubmit={submit} noValidate className="grid gap-4 sm:grid-cols-2 bg-white/70 p-6 border border-gold/40" aria-label={tr.inquiry}>
      <label className="text-sm">{tr.cin}<input type="date" className={I} value={f.cin} onChange={e => set('cin', e.target.value)} />{err.cin && <span role="alert" className="text-red-700 text-xs">{err.cin}</span>}</label>
      <label className="text-sm">{tr.cout}<input type="date" className={I} value={f.cout} onChange={e => set('cout', e.target.value)} />{err.cout && <span role="alert" className="text-red-700 text-xs">{err.cout}</span>}</label>
      <label className="text-sm">{tr.ad}<input type="number" min={1} max={12} className={I} value={f.ad} onChange={e => set('ad', e.target.value)} />{err.ad && <span role="alert" className="text-red-700 text-xs">{err.ad}</span>}</label>
      <label className="text-sm">{tr.ch}<input type="number" min={0} max={10} className={I} value={f.ch} onChange={e => set('ch', e.target.value)} />{err.ch && <span role="alert" className="text-red-700 text-xs">{err.ch}</span>}</label>
      <label className="text-sm sm:col-span-2">{tr.rp}<select className={I} value={f.room} onChange={e => set('room', e.target.value)}><option value="">{tr.any}</option>{rooms.map(r => <option key={r.id}>{r.name}</option>)}</select></label>
      <button className="btn btn-dark sm:col-span-2">{tr.prev}</button>
      {txt && <div className="sm:col-span-2"><pre className="whitespace-pre-wrap bg-ivory p-3 text-sm border border-walnut/20">{txt}</pre>
        <button type="button" className="btn btn-gold mt-2" onClick={() => navigator.clipboard?.writeText(txt).then(() => setOk(true))}>{tr.copy}</button>{ok && <span className="ml-3 text-sm">Copied</span>}</div>}
      <p className="text-xs sm:col-span-2 text-walnut">{tr.note}</p>
    </form>)
}

function Gallery() {
  const [i, setI] = useState<number | null>(null)
  useEffect(() => { const k = (e: KeyboardEvent) => { if (i === null) return; if (e.key === 'Escape') setI(null); if (e.key === 'ArrowRight') setI((i + 1) % gallery.length); if (e.key === 'ArrowLeft') setI((i + gallery.length - 1) % gallery.length) }; addEventListener('keydown', k); return () => removeEventListener('keydown', k) }, [i])
  return (<>
    <div className="columns-2 md:columns-3 gap-3 [&>button]:mb-3">{gallery.map((g, n) => <button key={g.src} onClick={() => setI(n)} className="block w-full overflow-hidden"><img src={g.src} alt={g.alt} loading="lazy" className="w-full hover:scale-105 transition-transform duration-700" /></button>)}</div>
    {i !== null && <div role="dialog" aria-modal="true" aria-label="Photo viewer" className="fixed inset-0 z-50 bg-charcoal/95 flex flex-col items-center justify-center p-4" onClick={() => setI(null)}>
      <img src={gallery[i].src} alt={gallery[i].alt} className="max-h-[80vh] max-w-full object-contain" onClick={e => e.stopPropagation()} />
      <p className="text-ivory text-sm mt-3">{gallery[i].alt}</p>
      <div className="flex gap-3 mt-3" onClick={e => e.stopPropagation()}><button className="btn btn-line" onClick={() => setI((i + gallery.length - 1) % gallery.length)}>Prev</button><button className="btn btn-line" onClick={() => setI(null)}>Close</button><button className="btn btn-line" onClick={() => setI((i + 1) % gallery.length)}>Next</button></div></div>}
  </>)
}

const Section = ({ id, title, children, dark = false }: { id?: string; title?: string; children: React.ReactNode; dark?: boolean }) =>
  <section id={id} className={`${dark ? 'bg-forest text-ivory' : ''} py-16 px-5`}><div className="max-w-6xl mx-auto fade">{title && <h2 className={`text-4xl mb-8 ${dark ? '!text-ivory' : ''}`}>{title}</h2>}{children}</div></section>

export default function App() {
  const [lang, setLang] = useState<Lang>('en'); const [menu, setMenu] = useState(false); const tr = t[lang]; const route = useRoute()
  useEffect(() => { document.documentElement.lang = lang }, [lang])
  const nav: [string, string][] = [[tr.home, '#/'], [tr.story, '#/story'], [tr.rooms, '#/rooms'], [tr.exp, '#/experiences'], [tr.gallery, '#/gallery'], [tr.reviews, '#/reviews'], [tr.explore, '#/explore'], [tr.contact, '#/contact']]
  const [page, arg] = route.split('/').filter(Boolean)
  const room = rooms.find(r => r.id === arg)
  useEffect(() => { document.title = `${room ? room.name : page || 'Home'} — Guest House Third Floor (private demo)` }, [page, room])
  const Rooms = () => <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">{rooms.map(r => <a key={r.id} href={`#/room/${r.id}`} className="group bg-white block">
    <div className="aspect-[4/3] overflow-hidden bg-forest/10">{r.photos.length ? <Img src={roomImg(r, 0)} alt={`${r.name}, photo to be confirmed`} cls="group-hover:scale-105 transition-transform duration-700" /> : <div className="h-full flex items-center justify-center text-sm p-4 text-center">Photos for this room are awaiting confirmation</div>}</div>
    <div className="p-5"><h3 className="text-2xl">{r.name}</h3><p className="text-sm text-walnut mt-1">{r.beds}</p><p className="text-sm mt-2">{r.audience}</p></div></a>)}</div>
  return (<div>
    <div className="bg-charcoal text-ivory text-xs text-center py-2 px-3">{tr.demo}</div>
    <header className="sticky top-0 z-40 bg-ivory/95 border-b border-gold/40"><div className="max-w-6xl mx-auto flex items-center justify-between px-5 py-3">
      <a href="#/" className="font-serif text-2xl text-forest leading-none">Guest House <span className="italic text-gold">Third Floor</span></a>
      <nav aria-label="Main" className="hidden lg:flex gap-5 text-sm">{nav.map(([l, h]) => <a key={h} href={h} className="hover:text-gold">{l}</a>)}</nav>
      <div className="flex items-center gap-2"><label className="sr-only" htmlFor="lang">Language</label><select id="lang" value={lang} onChange={e => setLang(e.target.value as Lang)} className="bg-transparent border border-walnut/40 text-sm px-1 py-1"><option value="en">EN</option><option value="ka">ქართ</option><option value="ru">RU</option></select>
        <a href="#/contact" className="btn btn-dark hidden sm:inline-flex !py-2">{tr.check}</a>
        <button className="lg:hidden btn btn-dark !py-2 !px-3" aria-expanded={menu} aria-label="Menu" onClick={() => setMenu(!menu)}>☰</button></div></div>
      {menu && <nav className="lg:hidden bg-ivory px-5 pb-4 grid gap-3" aria-label="Mobile">{nav.map(([l, h]) => <a key={h} href={h} onClick={() => setMenu(false)}>{l}</a>)}<a href="#/contact" onClick={() => setMenu(false)} className="font-semibold">{tr.check}</a></nav>}
    </header>
    <main>
    {(!page) && <>
      <section className="relative min-h-[78vh] flex items-end text-ivory"><div className="absolute inset-0"><Img src={pics.hero} alt="Living room with fireplace and parquet floor" /><div className="absolute inset-0 bg-forest/55" /></div>
        <div className="relative max-w-6xl mx-auto px-5 pb-16 fade"><h1 className="text-5xl md:text-7xl !text-ivory max-w-3xl">{tr.h1}</h1><p className="mt-5 max-w-xl text-lg">{tr.sub}</p>
          <div className="mt-7 flex flex-wrap gap-3"><a href="#/rooms" className="btn btn-gold">{tr.cta1}</a><a href="#/contact" className="btn btn-line">{tr.cta2}</a></div><div className="mt-6"><Rating /></div></div></section>
      <Section id="inq" title={tr.inquiry}><Inquiry tr={tr} /></Section>
      <Section title="Why guests choose us" dark><div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">{ratings.categories.map(([k, v]) => <div key={k} className="border-t border-gold pt-3"><p className="font-serif text-5xl text-gold">{v}</p><p>{k}</p></div>)}</div><p className="text-xs mt-6 opacity-80">Booking.com category scores from the supplied snapshot, not combined with any other platform.</p></Section>
      <Section title={tr.storyH}><div className="grid md:grid-cols-2 gap-10 items-center"><p className="text-lg leading-relaxed">{tr.storyP}</p><div className="grid grid-cols-2 gap-3 h-80"><Img src={pics.door} alt="Carved red wooden street door" /><Img src={pics.stove} alt="Antique tiled stove" /></div></div></Section>
      <Section title={tr.rooms}><Rooms /></Section>
    </>}
    {page === 'story' && <Section title={tr.storyH}><p className="text-lg max-w-2xl">{tr.storyP}</p><div className="grid md:grid-cols-3 gap-3 h-72 mt-8"><Img src={pics.door} alt="Street door" /><Img src={pics.hall} alt="Arched hallway with piano" /><Img src={pics.hero} alt="Living room with fireplace" /></div>
      <h2 className="text-3xl mt-12 mb-3">Your host</h2><p className="max-w-2xl">{P.name} is run by its family. The property manager listed publicly is {P.manager}; languages spoken are {P.languagesSpoken}. A personal introduction will be added once {P.manager} provides one.</p></Section>}
    {page === 'rooms' && <Section title={tr.rooms}><Rooms /><p className="mt-6 text-sm">{tr.rates}</p></Section>}
    {page === 'room' && room && <Section title={room.name}>
      <div className="grid md:grid-cols-3 gap-3 mb-8">{room.photos.length ? room.photos.map((_, i) => <div key={i} className="aspect-[4/3]"><Img src={roomImg(room, i)} alt={`${room.name}, photo ${i + 1}`} /></div>) : <p className="md:col-span-3 bg-white p-6">Photographs for this room category are awaiting manager confirmation.</p>}</div>
      <div className="grid md:grid-cols-2 gap-10"><div><p className="text-lg">{room.blurb}</p><dl className="mt-5 grid gap-2 text-sm"><div><dt className="font-semibold inline">Beds: </dt><dd className="inline">{room.beds}</dd></div><div><dt className="font-semibold inline">Best for: </dt><dd className="inline">{room.audience}</dd></div><div><dt className="font-semibold inline">Maximum occupancy: </dt><dd className="inline">to be confirmed by the manager</dd></div><div><dt className="font-semibold inline">Bathroom: </dt><dd className="inline">private</dd></div><div><dt className="font-semibold inline">Rates: </dt><dd className="inline">{tr.rates}</dd></div></dl>
        <p className="mt-4 text-sm text-walnut">Accessibility details have not been confirmed; please call to ask. Photo-to-room matching is based on visible bed layouts and awaits confirmation.</p>
        <h3 className="text-2xl mt-8 mb-2">Other rooms</h3><ul className="flex flex-wrap gap-3">{rooms.filter(r => r.id !== room.id).map(r => <li key={r.id}><a className="underline" href={`#/room/${r.id}`}>{r.name}</a></li>)}</ul></div>
        <div><h3 className="text-2xl mb-3">Reservation inquiry</h3><Inquiry tr={tr} pre={room.name} /></div></div></Section>}
    {page === 'experiences' && <><Section title={tr.exp}><div className="grid md:grid-cols-3 gap-3"><div className="h-64"><Img src={pics.hero} alt="Shared lounge" /></div><div className="h-64"><Img src={pics.dining} alt="Dining room with stained glass" /></div><div className="h-64"><Img src={pics.kitchen} alt="Shared kitchen" /></div><div className="h-64"><Img src={pics.balc[0]} alt="Balcony" /></div><div className="h-64"><Img src={pics.balc[1]} alt="Terrace-style balcony with flowers" /></div><div className="h-64"><Img src={pics.hall} alt="Hallway with piano" /></div></div></Section>
      <Section id="breakfast" title={tr.bfH} dark><div className="grid md:grid-cols-3 gap-3 mb-6">{pics.bf.map((b, i) => <div key={b} className="h-72"><Img src={b} alt={['Breakfast spread with eggs, cheese and honey', 'Omelette with vegetables and coffee', 'Warm curd pancakes with fruit'][i]} /></div>)}</div><p className="max-w-2xl">{tr.bfP}</p></Section>
      <Section title="Facilities"><div className="grid md:grid-cols-2 gap-10"><div><h3 className="text-2xl mb-2">Property-wide</h3><ul className="list-disc ml-5 space-y-1">{propertyWide.map(a => <li key={a}>{a}</li>)}</ul></div><div><h3 className="text-2xl mb-2">In the rooms</h3><ul className="list-disc ml-5 space-y-1">{roomWide.map(a => <li key={a}>{a}</li>)}</ul><div className="grid grid-cols-3 gap-2 mt-4 h-40">{bathrooms.map((b, i) => <Img key={b} src={b} alt={`Private bathroom with walk-in shower ${i + 1}`} />)}</div></div></div><p className="text-sm mt-6">Not all services are free of charge, and none of these lists imply a pool, spa, gym, bar or 24-hour reception.</p></Section></>}
    {page === 'gallery' && <Section title={tr.gallery}><Gallery /></Section>}
    {page === 'reviews' && <Section title={tr.reviews}><div className="bg-white p-6 mb-8"><p className="font-serif text-6xl text-forest">{ratings.score}<span className="text-2xl">/10</span></p><p>{ratings.source} · {ratings.label} · {ratings.reviews} reviews (snapshot, to be reverified)</p><div className="grid sm:grid-cols-2 gap-x-10 mt-4">{ratings.categories.map(([k, v]) => <div key={k} className="flex justify-between border-b py-1"><span>{k}</span><strong>{v}</strong></div>)}</div></div>
      <h3 className="text-2xl mb-3">What guests talk about</h3><p className="text-sm mb-4 text-walnut">Paraphrased themes from published guest feedback, not verbatim testimonials, and not verified by this website.</p><div className="grid md:grid-cols-2 gap-4">{themes.map(([a, b]) => <div key={a} className="border-l-2 border-gold pl-4"><h4 className="font-semibold">{a}</h4><p>{b}</p></div>)}</div>
      <a className="btn btn-dark mt-8" href={P.bookingLink} target="_blank" rel="noopener noreferrer">Read reviews on Booking.com</a></Section>}
    {page === 'explore' && <Section title={tr.explore}><p className="max-w-2xl mb-6">Chugureti is a lived-in central neighbourhood. These landmarks are listed for planning; distances and travel times are intentionally left to the live map links. The published airport distance is about 16 km.</p><ul className="grid sm:grid-cols-2 gap-2">{places.map(p => <li key={p} className="flex justify-between border-b py-2"><span>{p}</span><a className="underline" target="_blank" rel="noopener noreferrer" href={dirLink(p)}>Directions</a></li>)}</ul><div className="h-72 mt-8"><Img src={pics.view} alt="Rooftop view toward the hills" /></div></Section>}
    {page === 'contact' && <Section title={tr.contact}><div className="grid md:grid-cols-2 gap-10"><div className="space-y-3"><p>{P.address}</p><p>Languages: {P.languagesSpoken}</p><div className="flex flex-wrap gap-3"><a className="btn btn-dark" href={P.tel}>Call {P.phone}</a><a className="btn btn-gold" href={P.mapsLink} target="_blank" rel="noopener noreferrer">Directions</a><a className="btn btn-dark" href={P.bookingLink} target="_blank" rel="noopener noreferrer">Booking.com</a></div><p className="text-sm text-walnut">No email address is published here and WhatsApp is disabled until the manager confirms it. {tr.rates}</p></div><Inquiry tr={tr} /></div></Section>}
    </main>
    <footer className="bg-charcoal text-ivory py-10 px-5 text-sm"><div className="max-w-6xl mx-auto grid md:grid-cols-3 gap-6"><div><p className="font-serif text-xl">Guest House Third Floor</p><p>{P.address}</p></div><div><a href={P.tel} className="underline">{P.phone}</a><br /><a href={P.mapsLink} className="underline" target="_blank" rel="noopener noreferrer">Directions</a></div><div><p>Privacy: this demo collects and transmits no personal data.</p><p>{tr.demo}</p></div></div></footer>
    <a href={P.tel} className="sm:hidden fixed bottom-3 left-3 right-3 z-40 btn btn-gold shadow-lg">Call to reserve · {P.phone}</a>
  </div>)
}
