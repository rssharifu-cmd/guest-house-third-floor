export type Lang = 'en' | 'ka' | 'ru'
const img = (c: string, n: number) => `./images/${c}/photo-${String(n).padStart(2, '0')}.webp`
export const property = {
  name: 'Guest House Third Floor',
  manager: 'Sofia Mgeladze',
  address: '24b Egnate Ninoshvili Street, 3rd Floor, Chugureti, Tbilisi 0112, Georgia',
  phone: '+995 577 58 58 68', tel: 'tel:+995577585868',
  mapsLink: 'https://www.google.com/maps/search/?api=1&query=Guest+House+Third+Floor+Tbilisi+Georgia',
  bookingLink: 'https://www.booking.com/hotel/ge/guesthouse-3rd-floor.en-gb.html',
  languagesSpoken: 'English, Russian',
  whatsappEnabled: false, // keep false until manager confirms the number supports WhatsApp
}
// Snapshot from the supplied photo PDF (compiled 27 Nov 2026). Differs from the earlier brief (9.6 / 278 reviews): re-verify before launch.
export const ratings = { source: 'Booking.com', score: 9.5, reviews: 248, label: 'Exceptional',
  categories: [['Staff', 9.7], ['Value for money', 9.6], ['Location', 9.6], ['Cleanliness', 9.5]] as [string, number][] }
export type Room = { id: string; name: string; beds: string; audience: string; blurb: string; photos: number[]; photoCats: string[]; verified: boolean }
export const rooms: Room[] = [
  { id: 'twin-balcony', name: 'Twin Room with Balcony', beds: 'Two single beds', audience: 'Friends, travelling companions and solo travellers',
    blurb: 'Two white-framed single beds, parquet flooring and tall windows, with a door out to the balcony.', photos: [40, 39, 51], photoCats: ['rooms','rooms','rooms'], verified: false },
  { id: 'double-balcony', name: 'Double Room with Balcony', beds: 'One king-sized bed', audience: 'Couples',
    blurb: 'A calm, private room with a large bed, a velvet armchair and glass doors that open to the balcony.', photos: [30, 18, 27], photoCats: ['rooms','rooms','rooms'], verified: false },
  { id: 'family', name: 'Family Room', beds: 'One single bed and one queen-sized bed', audience: 'Small families and groups',
    blurb: 'A practical room for a small family, with a private bathroom. Photographs for this exact room are awaiting manager confirmation.', photos: [], photoCats: [], verified: false },
  { id: 'deluxe-family', name: 'Deluxe Family Room', beds: 'One king-sized bed, two bunk beds and one sofa bed', audience: 'Larger families and groups',
    blurb: 'A high-ceilinged room with period details, a traditional tiled stove, bunk beds and a sofa bed. Maximum occupancy to be confirmed with the manager.', photos: [49, 50, 34, 33], photoCats: ['rooms','rooms','rooms','rooms'], verified: false },
  { id: 'family-balcony', name: 'Family Room with Balcony', beds: 'Two single beds and two bunk beds', audience: 'Families and small groups',
    blurb: 'A generous room with parquet floors, single beds, bunk beds, a sofa and a balcony door.', photos: [44, 47, 46], photoCats: ['rooms','rooms','rooms'], verified: false },
]
export const roomImg = (r: Room, i: number) => img(r.photoCats[i], r.photos[i])
export const pics = {
  hero: img('interior', 38), door: img('exterior', 7), lounge: img('interior', 52), stove: img('interior', 45), hall: img('interior', 5),
  dining: img('interior', 35), kitchen: img('interior', 37), kitchen2: img('interior', 53), glass: img('interior', 36),
  bf: [img('breakfast', 15), img('breakfast', 31), img('breakfast', 32)],
  balc: [img('balcony', 17), img('balcony', 41), img('balcony', 13), img('balcony', 22)], view: img('exterior', 21), dusk: img('exterior', 48),
  logo: './images/exterior/logo-original.webp',
}
export const gallery: { src: string; alt: string }[] = [
  [pics.hero, 'Shared living room with marble fireplace, parquet floor and grey sofas'], [pics.door, 'Carved red wooden street door of the brick building at number 24'],
  [pics.hall, 'Arched hallway with brass wall lamps and an upright piano on herringbone parquet'], [pics.dining, 'Sunny shared dining room with stained-glass transom windows'],
  [pics.kitchen, 'Shared kitchen and dining area with checked tablecloths'], [pics.stove, 'Antique tiled stove with plasterwork crest'],
  [pics.bf[0], 'Breakfast spread with eggs, cheese, honey, cold cuts and fresh bread'], [pics.bf[1], 'Omelette with vegetables, toast, fruit and coffee'],
  [pics.bf[2], 'Warm curd pancakes with banana and kiwi'], [pics.balc[0], 'Balcony with small table overlooking a leafy street'],
  [pics.balc[1], 'Balcony with flowers and a view toward the hills'], [pics.view, 'View over rooftops to the hills and TV tower'],
  [pics.dusk, 'Evening view over Tbilisi rooftops'], ...rooms.flatMap(r => r.photos.map((_, i) => [roomImg(r, i), `${r.name} (to be confirmed)`] as [string, string])),
].map(([src, alt]) => ({ src, alt })).filter((g, i, a) => a.findIndex(x => x.src === g.src) === i)
export const bathrooms = [img('bathrooms', 29), img('bathrooms', 16), img('bathrooms', 2)]
export const propertyWide = ['Free WiFi', 'Shared kitchen', 'Shared lounge', 'Dining area', 'Terrace', 'Breakfast (see breakfast page)', 'Family rooms', 'Non-smoking rooms', 'Laundry service (listed; terms to confirm)', 'Airport shuttle (listed; may carry a charge)', 'Parking (availability and charges to confirm)']
export const roomWide = ['Private bathroom with walk-in shower', 'Air conditioning (visible in room photos)', 'Heating (radiators visible in room photos)', 'Parquet flooring', 'Balcony access in the balcony room categories']
export const themes = [
  ['Balcony and view', 'Guests from the United States have appreciated the balcony view and the comfortable accommodation.'],
  ['Host and atmosphere', 'A guest from Egypt highlighted the welcoming host, cleanliness, cosy feel and affordability.'],
  ['Kitchen', 'A guest from India valued the comfortable stay and practical kitchen facilities.'],
  ['Location and responsiveness', 'A guest from the UAE appreciated the location and a host who responds promptly.'],
  ['Breakfast and calm', 'A guest from Georgia noted the peaceful surroundings, cultural setting, breakfast variety and the host.'],
  ['Coming back', 'A guest from Russia reported returning to the property several times.'],
]
export const places = ['Fabrika Tbilisi', 'Dry Bridge Market', 'Agmashenebeli Avenue', 'Marjanishvili Metro Station', 'Art Palace of Georgia', 'Tbilisi Central Railway Station', 'State Silk Museum', 'Dinamo Arena', 'Dezerter Bazaar', 'Rustaveli Theatre', 'Freedom Square', 'Narikala Fortress', 'Bridge of Peace', 'Tbilisi Sulfur Baths', 'Tbilisi International Airport']
export const dirLink = (p: string) => `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent('Guest House Third Floor Tbilisi')}&destination=${encodeURIComponent(p + ' Tbilisi')}`
export const t: Record<Lang, Record<string, string>> = {
  en: { home: 'Home', story: 'Our Story', rooms: 'Rooms', exp: 'Experiences', gallery: 'Gallery', reviews: 'Guest Reviews', explore: 'Explore Tbilisi', contact: 'Contact', check: 'Check Availability',
    h1: 'A Historic Home. A Warm Georgian Welcome.', sub: 'Experience the charm of Tbilisi in a family-run guesthouse where historic character meets everyday comfort.', cta1: 'Explore Our Rooms', cta2: 'Check Availability',
    storyH: 'A family apartment, opened to travellers', storyP: 'Set in a nineteenth-century building with high ceilings and wooden floors, the apartment has long been a family home where relatives and friends gathered. Today it welcomes guests from around the world.',
    inquiry: 'Reservation inquiry', cin: 'Check-in', cout: 'Check-out', ad: 'Adults', ch: 'Children', rp: 'Room preference', any: 'No preference', prev: 'Preview my inquiry', copy: 'Copy inquiry', note: 'This demo does not send anything. Preview and copy your inquiry, then call or use Booking.com.', rates: 'Contact us for rates and availability.',
    bfH: 'Breakfast', bfP: 'A homely breakfast is one of the things guests mention most. Photographs show eggs, cheese, honey, fruit, pastries and warm dishes. Menu, hours and prices to be confirmed by the manager.', demo: 'Private concept by NetVentures — not an official website, not for public release.' },
  ka: { home: 'მთავარი', story: 'ჩვენი ამბავი', rooms: 'ოთახები', exp: 'სივრცეები', gallery: 'გალერეა', reviews: 'სტუმრების შეფასებები', explore: 'გაიცანით თბილისი', contact: 'კონტაქტი', check: 'ხელმისაწვდომობა',
    h1: 'ისტორიული სახლი. თბილი ქართული მასპინძლობა.', sub: 'იგრძენით თბილისის მომხიბვლელობა საოჯახო სასტუმრო სახლში, სადაც ისტორია და ყოველდღიური კომფორტი ერთად არის.', cta1: 'ოთახების ნახვა', cta2: 'ხელმისაწვდომობა',
    storyH: 'საოჯახო ბინა, გახსნილი სტუმრებისთვის', storyP: 'მეცხრამეტე საუკუნის შენობაში, მაღალი ჭერითა და ხის იატაკით მდებარე ბინა დიდი ხანია ოჯახის სახლი იყო. დღეს ის მსოფლიოს ყველა კუთხიდან მოსულ სტუმარს იღებს.',
    inquiry: 'დაჯავშნის მოთხოვნა', cin: 'შესვლა', cout: 'გასვლა', ad: 'მოზრდილი', ch: 'ბავშვი', rp: 'ოთახი', any: 'არ აქვს მნიშვნელობა', prev: 'მოთხოვნის ნახვა', copy: 'კოპირება', note: 'დემო არაფერს აგზავნის. დააკოპირეთ მოთხოვნა და დაგვირეკეთ.', rates: 'ფასებისა და ხელმისაწვდომობისთვის დაგვიკავშირდით.',
    bfH: 'საუზმე', bfP: 'სახლისებური საუზმე სტუმრების ერთ-ერთი საყვარელი დეტალია. მენიუ, საათები და ფასები დასაზუსტებელია.', demo: 'NetVentures-ის კერძო კონცეფცია — არაოფიციალური, საჯაროდ არ გამოქვეყნდეს. (თარგმანი მშობლიურმა ენამ უნდა გადაამოწმოს)' },
  ru: { home: 'Главная', story: 'Наша история', rooms: 'Номера', exp: 'Пространства', gallery: 'Галерея', reviews: 'Отзывы гостей', explore: 'Исследуйте Тбилиси', contact: 'Контакты', check: 'Проверить наличие',
    h1: 'Исторический дом. Тёплое грузинское гостеприимство.', sub: 'Почувствуйте очарование Тбилиси в семейном гостевом доме, где историческая атмосфера сочетается с повседневным комфортом.', cta1: 'Посмотреть номера', cta2: 'Проверить наличие',
    storyH: 'Семейная квартира, открытая для путешественников', storyP: 'Квартира в здании XIX века с высокими потолками и деревянными полами давно была семейным домом, где собирались родные и друзья. Сегодня здесь принимают гостей со всего мира.',
    inquiry: 'Запрос на бронирование', cin: 'Заезд', cout: 'Выезд', ad: 'Взрослые', ch: 'Дети', rp: 'Номер', any: 'Без предпочтений', prev: 'Просмотреть запрос', copy: 'Копировать', note: 'Демо ничего не отправляет. Скопируйте запрос и позвоните нам.', rates: 'Цены и наличие уточняйте по телефону.',
    bfH: 'Завтрак', bfP: 'Домашний завтрак — то, что гости отмечают чаще всего. Меню, часы и цены будут уточнены менеджером.', demo: 'Частная концепция NetVentures — неофициальный сайт, не для публикации. (Перевод требует проверки носителем языка)' },
}
