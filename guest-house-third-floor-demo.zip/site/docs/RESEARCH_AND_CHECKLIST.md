# Guest House Third Floor — private demo (NetVentures)

## Status
Unsolicited concept. noindex, no data collected or sent. Not an official site. No live web research was performed in this build; all facts come from the brief and the supplied photo PDF.

## Sources used
- Master brief (address, phone, manager, rooms, amenities, review themes, 9.6/278 Booking.com snapshot)
- Supplied PDF (compiled 27 Nov 2026 from Booking.com listing images): 53 photos, rating 9.5/10 from 248 reviews, Staff 9.7, Value 9.6, Location 9.6, Cleanliness 9.5

## Conflicts to confirm
1. Rating: brief says 9.6 / 278 reviews, PDF says 9.5 / 248. Site shows the PDF figure, labelled "snapshot, to be reverified". Category scores also differ (brief lists Comfort, Facilities, WiFi; PDF lists Staff).
2. Parking: PDF lists parking; brief says sources differ on availability and charges. Marked "to confirm".
3. Amenities in the PDF header (terrace, parking) vs brief list: confirm each.

## Manager checklist
- Maximum occupancy for every room (Deluxe Family especially)
- Which photos belong to which room; Family Room (1 single + 1 queen) has no matched photo
- Breakfast: included or paid, hours, real menu, dietary options
- Parking, airport shuttle and laundry terms and prices
- Check-in/out times, house rules, rates
- Official logo (PDF photo 24 is a logo; kept as a file only, not used in the design) and permission to use all photos publicly
- Email address (none invented), WhatsApp approval (disabled)
- Accessibility information
- Native-speaker review of Georgian and Russian text (drafts)
- Host photo and personal introduction, if wanted

## Photo handling
- 53 originals kept in public/images/originals. WebP copies in category folders; thumbnails in gallery/.
- Photos 1, 3, 6 (bathrooms) show a person reflected in the mirror: excluded from the site, kept in originals.
- Photo 24 is a logo, saved as exterior/logo-original.webp, not displayed.
- Images are Booking.com listing images at up to 1024 px wide. Fine for a private demo; request higher-resolution originals before launch.
- Room matching is by visible bed layout only (unconfirmed).

## QA
Production build passes (tsc + vite). All referenced image files exist. Not yet done: browser testing on real devices, Lighthouse, screen-reader pass, native-language review, sitemap/hreflang (demo is noindex; add at launch).

## Deploy
npm install; npm run build; upload dist/ to Cloudflare Pages. Keep noindex until approved.
